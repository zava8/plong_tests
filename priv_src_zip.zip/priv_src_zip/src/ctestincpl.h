/*
 * ctestincpl.h
 *
 *  Created on: 08-Feb-2022
 *      Author: viml
 */

#ifndef CTESTINCPL_H_
#define CTESTINCPL_H_

// namespace std {

class ctest_incpl {
	static int test_throy();
	static int test_thron();
	static int test_throy1();
	static int test_thron1();
};

// } /* namespace std */

#endif /* CTESTINCPL_H_ */
