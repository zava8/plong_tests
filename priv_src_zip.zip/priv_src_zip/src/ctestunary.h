/*
 * ctestunary.h
 *
 *  Created on: 08-Feb-2022
 *      Author: viml
 */

#ifndef CTESTUNARY_H_
#define CTESTUNARY_H_

// namespace std { {

class ctest_unary {
public:
	static int test_throy();
	static int test_thron();
	static int test_throy1();
	static int test_thron1();
};

// } /* namespace std */

#endif /* CTESTUNARY_H_ */
