/*
 * ctestminusop.h
 *
 *  Created on: 08-Feb-2022
 *      Author: viml
 */

#ifndef CTESTMINUSOP_H_
#define CTESTMINUSOP_H_

// namespace std {

class ctest_minus_op {
public:
	static int test_throy();
	static int test_thron();
	static int test_throy1();
	static int test_thron1();

};

// } /* namespace std */


#endif /* CTESTMINUSOP_H_ */
