/*
 * ctestdivop.h
 *
 *  Created on: 08-Feb-2022
 *      Author: viml
 */

#ifndef CTESTDIVOP_H_
#define CTESTDIVOP_H_

// namespace std {

class ctest_divop {
	public:
	static int test_divop_throy();
	static int test_divop_thron();
	static int test_divop_thron_self();
	static int test_divop_throy1();
	static int test_divop_thron1();
};

// } /* namespace std */

#endif /* CTESTDIVOP_H_ */
