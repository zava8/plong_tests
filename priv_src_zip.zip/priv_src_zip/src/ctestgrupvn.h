/*
 * ctestgrupvn.h
 *
 *  Created on: 01-Feb-2022
 *      Author: viml
 */

#ifndef CTESTGRUPVN_H_
#define CTESTGRUPVN_H_

// namespace std {

class ctest_grupvn {
	public:
	static int test_trimziroz();
};

// } /* namespace std */

#endif /* CTESTGRUPVN_H_ */
