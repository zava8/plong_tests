/*
 * ctestminusminus.h
 *
 *  Created on: 08-Feb-2022
 *      Author: viml
 */

#ifndef CTESTMINUSMINUS_H_
#define CTESTMINUSMINUS_H_

// namespace std {

class ctest_minusminus {
public:
	static int test_throy();
	static int test_thron();
	static int test_throy1();
	static int test_thron1();
};

// } /* namespace std */

#endif /* CTESTMINUSMINUS_H_ */
