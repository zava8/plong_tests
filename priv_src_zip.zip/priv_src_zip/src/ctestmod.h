/*
 * ctestmod.h
 *
 *  Created on: 08-Feb-2022
 *      Author: viml
 */

#ifndef CTESTMOD_H_
#define CTESTMOD_H_

// namespace std {

class ctest_mod {
public:
	static int test_throy();
	static int test_thron();
	static int test_throy1();
	static int test_thron1();
};

// } /* namespace std */

#endif /* CTESTMOD_H_ */
