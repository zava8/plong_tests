/*
 * ctestknstrktrstr.h
 *
 *  Created on: 04-Feb-2022
 *      Author: viml
 */

#ifndef CTESTKNSTRKTRSTR_H_
#define CTESTKNSTRKTRSTR_H_

// namespace std {

class ctest_knstrktr_str {
	public:
	static int test_kns_str_thro_yes();
	static int test_kns_str_ziro_value();
	static int test_kns_str_vn_no_thro();
	static int test_kns_str_vnpoint_no_thro();
	static int test_kns_str_overphlo_no();
	static int test_kns_str_underphlo_no();
	static int test_kns_str_trim();
	static int test_kns_str_decimal();
	static int test_kns_str();
	//	static int test_kns_str_negetive_val();
	//	static int test_kns_str_negetive_pl();
	static int test_kns_str_overphlo_yes();
	static int test_kns_str_underphlo_yes();
};

// } /* namespace std */

#endif /* CTESTKNSTRKTRSTR_H_ */
