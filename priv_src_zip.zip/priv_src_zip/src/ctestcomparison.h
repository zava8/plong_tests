/*
 * ctestcomparison.h
 *
 *  Created on: 01-Feb-2022
 *      Author: viml
 */

#ifndef CTESTCOMPARISON_H_
#define CTESTCOMPARISON_H_

// namespace std {

class ctest_comparison {
	public:
	static int test_copmarison_throy();
	static int test_copmarison_op();
	static int test_cmp_throy();
	static int test_cmp_thron();
	static int test_cmp_throy_ik();
	static int test_cmp_thron_ik();
	static int test_cmp_throy_ne();
	static int test_cmp_thron_ne();
};

// } /* namespace std */

#endif /* CTESTCOMPARISON_H_ */
