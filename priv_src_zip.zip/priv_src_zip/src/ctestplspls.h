/*
 * ctestplspls.h
 *
 *  Created on: 08-Feb-2022
 *      Author: viml
 */

#ifndef CTESTPLSPLS_H_
#define CTESTPLSPLS_H_

// namespace std {

class ctest_plspls {
public:
	static int test_throy();
	static int test_thron();
	static int test_throy1();
	static int test_thron1();

};

// } /* namespace std */

#endif /* CTESTPLSPLS_H_ */
