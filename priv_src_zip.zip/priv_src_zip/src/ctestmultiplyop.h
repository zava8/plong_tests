/*
 * ctestmultiplyop.h
 *
 *  Created on: 08-Feb-2022
 *      Author: viml
 */

#ifndef CTESTMULTIPLYOP_H_
#define CTESTMULTIPLYOP_H_

// namespace std {

class ctest_op {
	public:
	static int test_throy();
	static int test_thron();
	static int test_throy1();
	static int test_thron1();
};

// } /* namespace std */

#endif /* CTESTMULTIPLYOP_H_ */
