/*
 * ctestplusop.h
 *
 *  Created on: 02-Feb-2022
 *      Author: viml
 */

#ifndef CTESTPLUSOP_H_
#define CTESTPLUSOP_H_

// namespace std {

class ctest_plusop {
	public:
	static int test_plus_op();
	static int test_plus_op_near_ziro();
	static int test_plus_op_negetive_nmbrs();
	static int test_plus_underphlo_yes();
	static int test_plus_underphlo_no();
	static int test_plus_overphlo_yes();
	static int test_plus_overphlo_no();
	static int tn_rl();
//	static int runtests();
//	static int test_plusplus_op();
//	static int test_plusplusint_op();
//	static int test_plusb_op();
//	static int test_bplus_op();
//	static int test_assisgnplus_op();
};

// } /* namespace std */

#endif /* CTESTPLUSOP_H_ */
