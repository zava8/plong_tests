/*
 * cplongekseption.cpp
 *
 *  Created on: 19-Jan-2022
 *      Author: vimal
 */

#include "cplongekseption.h"

c_plong_ekseption::c_plong_ekseption() {
	// TODO Auto-generated constructor stub

}
const char* c_plong_ekseption::vat() {
	return "c_plong_minimumpl_error";
}
c_plong_ekseption::~c_plong_ekseption() {
	// TODO Auto-generated destructor stub
}

