/*
 * ctestminimumpl.h
 *
 *  Created on: 09-Feb-2022
 *      Author: viml
 */

#ifndef CTESTMINIMUMPL_H_
#define CTESTMINIMUMPL_H_

// namespace std {

class ctest_minimumpl {
public:
	static int test_throy();
	static int test_thron();
	static int test_throy1();
	static int test_thron1();

};

// } /* namespace std */


#endif /* CTESTMINIMUMPL_H_ */
