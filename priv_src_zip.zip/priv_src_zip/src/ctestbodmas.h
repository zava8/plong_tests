/*
 * ctestbodmas.h
 *
 *  Created on: 16-Feb-2022
 *      Author: viml
 */

#ifndef CTESTBODMAS_H_
#define CTESTBODMAS_H_

//namespace c8 {

class ctest_bodmas {
	public:
	static int tn();
	static int ty();
};

//} /* namespace c8 */

#endif /* CTESTBODMAS_H_ */
